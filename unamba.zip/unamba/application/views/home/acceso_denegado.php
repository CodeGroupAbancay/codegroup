<div class="row">
	<div class="col-md-6 col-md-push-2 text-center">
		<h1>No tiene Acceso a Esta Opcion !! </h1>
		<div class="box box-danger">
			<div class="box-body">
				<p> <img  class"img-responsive img-rounded" src="<?= base_url('fotos/acceso_denegado.png')?>"> </p>
		<p class="alert alert-info"> No tiene asignado el permiso para esta opcion, Comuniquese con el administrador</p>		
			</div>
		</div>
		
	</div>
</div>